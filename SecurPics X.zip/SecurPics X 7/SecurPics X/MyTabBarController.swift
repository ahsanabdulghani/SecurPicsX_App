//
//  MyNavigationController.swift
//  CustomTabShapeTest
//
//  Created by Philipp Weiß on 16.11.18.
//  Copyright © 2018 pmw. All rights reserved.
//

import UIKit

class MyTabBarController: UITabBarController {

	override func viewDidLoad() {
		super.viewDidLoad()
	}
}
