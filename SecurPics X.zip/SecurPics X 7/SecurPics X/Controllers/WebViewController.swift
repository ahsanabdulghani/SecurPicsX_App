import UIKit
import WebKit

class WebViewController: UIViewController {
    
    @IBOutlet var webView: WKWebView!
    var searchController: UISearchController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchController = UISearchController(searchResultsController: nil)
        searchController.searchBar.delegate = self
        navigationItem.searchController = searchController
        navigationItem.hidesSearchBarWhenScrolling = false
        definesPresentationContext = true
        
        loadURL("https://www.google.com")
    }
    
    func loadURL(_ urlString: String) {
        if let url = URL(string: urlString) {
            let request = URLRequest(url: url)
            webView.load(request)
        }
    }
    
    @IBAction func plusButtonTap(_ sender: Any) {
        NotificationCenter.default.post(name: Notification.Name("PlusButtonTapped"), object: nil)
        guard let tabBarController = self.tabBarController else {
                  return
              }
              tabBarController.selectedIndex = 0
    }
    
}

extension WebViewController: UISearchBarDelegate {
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        if let searchText = searchBar.text, let encodedSearchText = searchText.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) {
            let urlString = "https://www.google.com/search?q=\(encodedSearchText)"
            loadURL(urlString)
        }
        searchBar.resignFirstResponder()
    }
}
