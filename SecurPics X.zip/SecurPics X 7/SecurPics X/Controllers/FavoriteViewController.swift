import UIKit

class FavoriteViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    var favoriteImages: [UIImage] = []
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        NotificationCenter.default.addObserver(self, selector: #selector(imageAddedToFavorites(_:)), name: Notification.Name("ImageAddedToFavorites"), object: nil)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return favoriteImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FavoriteCell", for: indexPath) as! FavoriteCollectionViewCell
        
        let image = favoriteImages[indexPath.item]
        cell.imgView.image = image
        
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedImage = favoriteImages[indexPath.item]
        
        let backgroundView = UIView(frame: view.bounds)
        backgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        view.addSubview(backgroundView)
        
        let imageViewFrame = CGRect(x: 0, y: 0, width: 600, height: 600)
        
        let imageView = UIImageView(frame: imageViewFrame)
        imageView.image = selectedImage
        imageView.contentMode = .scaleAspectFit
        
        backgroundView.addSubview(imageView)
        
        imageView.center = backgroundView.center
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissImageView(_:)))
        backgroundView.addGestureRecognizer(tapGesture)
    }
    
    @objc func dismissImageView(_ sender: UITapGestureRecognizer) {
        sender.view?.removeFromSuperview()
    }
    
    func addImageToFavorites(_ image: UIImage) {
        favoriteImages.append(image)
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        collectionView.reloadData()
    }
    
    @objc func imageAddedToFavorites(_ notification: Notification) {
        if let image = notification.object as? UIImage {
            addImageToFavorites(image)
        }
        self.collectionView.reloadData()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @IBAction func plusButtonTap(_ sender: Any) {
        NotificationCenter.default.post(name: Notification.Name("PlusButtonTapped"), object: nil)
        guard let tabBarController = self.tabBarController else {
                  return
              }
              tabBarController.selectedIndex = 0
    }
    
}
