//
//  SplashScreenViewController.swift
//  SecurPics X
//
//  Created by MacBook Pro on 21/02/2024.
//

import UIKit

class SplashScreenViewController: UIViewController {
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    @IBOutlet weak var imgViewLogo: UIImageView!
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        activityIndicator.startAnimating()
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.0) {
            self.activityIndicator.stopAnimating()
            self.performSegue(withIdentifier: "CreatePasswordViewController", sender: self)

        }
        // Make imgViewLogo round
                imgViewLogo.layer.cornerRadius = imgViewLogo.frame.size.width / 3
                imgViewLogo.clipsToBounds = true
    }

}
