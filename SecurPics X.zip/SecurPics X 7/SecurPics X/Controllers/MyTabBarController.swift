import UIKit

class MyTabBarController: UITabBarController {
    var userId: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
