import UIKit
import PhotosUI
import Photos

class AlbumViewController: UIViewController, FavoriteCollectionViewCellDelegate {
    var favoriteViewController: FavoriteViewController?
    var isFavoriteArray: [Bool] = []
    
    @IBOutlet weak var collectionView: UICollectionView!
    var images: [UIImage] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCollectionView()
        collectionView.contentInsetAdjustmentBehavior = .never
        collectionView.contentInset.bottom = collectionView.safeAreaInsets.bottom
        collectionView.isScrollEnabled = true
        isFavoriteArray = Array(repeating: false, count: images.count)
        
        NotificationCenter.default.addObserver(self, selector: #selector(plusButtonTapped), name: Notification.Name("PlusButtonTapped"), object: nil)
        
    }
    
    @objc func plusButtonTapped() {
        showAddPhotoOptions()
        
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if UserDefaults.standard.bool(forKey: "userLoggedIn") {
            if let userInput = UserDefaults.standard.string(forKey: "userPassword") {
                let userImagesKey = "userImages_\(userInput)"
                if let imageDataArray = UserDefaults.standard.array(forKey: userImagesKey) as? [Data] {
                    self.images = imageDataArray.compactMap { UIImage(data: $0) }
                    self.isFavoriteArray = Array(repeating: false, count: self.images.count)
                }
                collectionView.reloadData()
            }
        } else {
            self.images.removeAll()
            self.isFavoriteArray.removeAll()
            collectionView.reloadData()
        }
    }
    private func saveImagesForCurrentUser() {
        if let userInput = UserDefaults.standard.string(forKey: "userPassword") {
            let userImagesKey = "userImages_\(userInput)"
            let imageDataArray = self.images.compactMap { $0.pngData() }
            UserDefaults.standard.set(imageDataArray, forKey: userImagesKey)
            UserDefaults.standard.synchronize()
        }
    }
    
    private func setupCollectionView() {
//        let layout = UICollectionViewFlowLayout()
//        layout.minimumInteritemSpacing = 8
//        layout.minimumLineSpacing = 8
//
//        let collectionViewWidth = collectionView.bounds.width
//        let itemWidth = (collectionViewWidth - layout.minimumInteritemSpacing * 3) / 2 // Subtracting the spacing between cells
//
//        layout.itemSize = CGSize(width: itemWidth, height: itemWidth)
//
//        collectionView.setCollectionViewLayout(layout, animated: false)
        collectionView.dataSource = self
        collectionView.delegate = self
    }

    
    @IBAction func plusButtonTap(_ sender: Any) {
        showAddPhotoOptions()
    }
    
    private func showAddPhotoOptions() {
        let alertController = UIAlertController(title: "Add Photo", message: "Choose a source", preferredStyle: .actionSheet)
        
        let libraryAction = UIAlertAction(title: "Photo Library", style: .default) { _ in
            self.showPhotoLibrary()
        }
        alertController.addAction(libraryAction)
        
        let cameraAction = UIAlertAction(title: "Camera", style: .default) { _ in
            self.showCamera()
        }
        alertController.addAction(cameraAction)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    private func showPhotoLibrary() {
        var config = PHPickerConfiguration()
        config.selectionLimit = 6
        
        let phpicker = PHPickerViewController(configuration: config)
        phpicker.delegate = self
        present(phpicker, animated: true, completion: nil)
    }
    
    private func showCamera() {
        let cameraAuthorizationStatus = AVCaptureDevice.authorizationStatus(for: .video)
        
        switch cameraAuthorizationStatus {
        case .authorized:
            DispatchQueue.main.async {
                self.showImagePicker(sourceType: .camera)
            }
        case .notDetermined:
            requestCameraPermission { granted in
                if granted {
                    DispatchQueue.main.async {
                        self.showImagePicker(sourceType: .camera)
                    }
                } else {
                    print("Camera access denied")
                }
            }
        case .denied, .restricted:
            print("Camera access denied or restricted")
        @unknown default:
            break
        }
    }
    
    
    private func requestCameraPermission(completion: @escaping (Bool) -> Void) {
        AVCaptureDevice.requestAccess(for: .video) { granted in
            completion(granted)
        }
    }
    
    private func showImagePicker(sourceType: UIImagePickerController.SourceType) {
        guard UIImagePickerController.isSourceTypeAvailable(sourceType) else {
            return
        }
        
        let imagePicker = UIImagePickerController()
        imagePicker.sourceType = sourceType
        imagePicker.delegate = self
        present(imagePicker, animated: true) {
            self.isFavoriteArray = Array(repeating: false, count: self.images.count)
        }
    }
    
    func favoriteButtonTapped(at indexPath: IndexPath) {
        let selectedImage = images[indexPath.item]
        favoriteViewController?.addImageToFavorites(selectedImage)
        NotificationCenter.default.post(name: Notification.Name("ImageAddedToFavorites"), object: selectedImage)
        isFavoriteArray[indexPath.item].toggle()
        collectionView.reloadData()
    }
}

extension AlbumViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCell", for: indexPath) as! ImageCollectionViewCell
        let isFavorite = isFavoriteArray[indexPath.item]
        cell.configure(with: images[indexPath.item], at: indexPath, isFavorite: isFavorite)
        cell.favoriteButton.setImage(UIImage(systemName: isFavorite ? "heart.fill.red" : "heart"), for: .normal)
        cell.delegate = self
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let selectedImage = images[indexPath.item]
        
        
        let backgroundView = UIView(frame: view.bounds)
        backgroundView.backgroundColor = UIColor.black.withAlphaComponent(0.5)
        view.addSubview(backgroundView)
        
        
        let imageViewFrame = CGRect(x: 0, y: 0, width: 600, height: 600)
        
        let imageView = UIImageView(frame: imageViewFrame)
        imageView.image = selectedImage
        imageView.contentMode = .scaleAspectFit
        
        backgroundView.addSubview(imageView)
        
        imageView.center = backgroundView.center
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dismissImageView(_:)))
        backgroundView.addGestureRecognizer(tapGesture)
    }
    
    @objc func dismissImageView(_ sender: UITapGestureRecognizer) {
        sender.view?.removeFromSuperview()
    }
    
    
}

extension AlbumViewController: PHPickerViewControllerDelegate {
    func picker(_ picker: PHPickerViewController, didFinishPicking results: [PHPickerResult]) {
        dismiss(animated: true)
        
        for result in results {
            result.itemProvider.loadObject(ofClass: UIImage.self) { object, error in
                if let image = object as? UIImage {
                    DispatchQueue.main.async {
                        self.images.append(image)
                        self.isFavoriteArray.append(false)
                        self.collectionView.reloadData()
                        self.collectionView.collectionViewLayout.invalidateLayout()
                        self.saveImagesForCurrentUser()
                        
                        let imageDataArray = self.images.map { $0.pngData() }
                        UserDefaults.standard.set(imageDataArray, forKey: "userImages")
                    }
                }
            }
        }
    }
}

extension AlbumViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        DispatchQueue.main.async {
            if let image = info[.originalImage] as? UIImage {
                self.images.append(image)
                self.isFavoriteArray.append(false)
                self.collectionView.reloadData()
                self.saveImagesForCurrentUser()
            }
            picker.dismiss(animated: true, completion: nil)
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
