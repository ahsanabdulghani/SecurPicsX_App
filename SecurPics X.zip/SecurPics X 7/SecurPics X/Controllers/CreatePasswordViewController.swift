import UIKit

class CreatePasswordViewController: UIViewController {
    
    @IBOutlet weak var eyeBtn: UIButton!
    @IBOutlet weak var imgViewLogo: UIImageView!
    @IBOutlet weak var okBtn: UIButton!
    @IBOutlet weak var passwordTextField: UITextField!
    var iconClick = true
    @IBOutlet weak var LBL: UILabel!
    public let passwordKey = "userPassword"
    var savedPassword = ""
    var isEnteringPassword = true
    var isConfirmingPassword = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        okBtn.layer.cornerRadius = 5
        passwordTextField.layer.cornerRadius = 8
        passwordTextField.layer.borderWidth = 1.0
        passwordTextField.layer.borderColor = UIColor.black.cgColor
        passwordTextField.clipsToBounds = true
        imgViewLogo.layer.cornerRadius = imgViewLogo.frame.size.width / 3
        imgViewLogo.clipsToBounds = true
        
        let tap = UITapGestureRecognizer(target: view, action: #selector(UIView.endEditing))
        view.addGestureRecognizer(tap)
    }
    
    @IBAction func iconAction(sender: AnyObject) {
        if iconClick {
            passwordTextField.isSecureTextEntry = false
        } else {
            passwordTextField.isSecureTextEntry = true
        }
        eyeBtn.isSelected.toggle()
        iconClick = !iconClick
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if UserDefaults.standard.bool(forKey: "userLoggedIn") {
            LBL.text = "ENTER PASSWORD"
            isEnteringPassword = true
            isConfirmingPassword = false
            
        } else {
            LBL.text = "ENTER PASSWORD"
            isEnteringPassword = true
            isConfirmingPassword = false
        }
    }
    
    func savePasswordToUserDefaults(_ userInput: String) {
        UserDefaults.standard.set(userInput, forKey: passwordKey)
        UserDefaults.standard.set(true, forKey: "userLoggedIn")
        UserDefaults.standard.synchronize()
        presentNextViewController()
    }
    
    @IBAction func submitBtn(_ sender: Any) {
        guard let userInput = passwordTextField.text, !userInput.isEmpty else {
            return
        }
        
        if isEnteringPassword {
            if let savedPassword = UserDefaults.standard.string(forKey: passwordKey), userInput == savedPassword {
                presentNextViewController()
            } else {
                
                LBL.text = "CONFIRM PASSWORD"
                passwordTextField.text = ""
                savedPassword = userInput
                isEnteringPassword = false
                isConfirmingPassword = true
            }
        } else if isConfirmingPassword {
            if userInput == savedPassword {
                savePasswordToUserDefaults(userInput)
            } else {
                handleMismatchedPasswords()
            }
        }
    }
    
    func handleMismatchedPasswords() {
        showAlert(message: "Confirm Password Does Not Match. Please enter the password again.")
        LBL.text = "ENTER PASSWORD"
        passwordTextField.text = ""
        savedPassword = ""
        isEnteringPassword = true
        isConfirmingPassword = false
    }
    
    func presentNextViewController() {
        if let destinationViewController = storyboard?.instantiateViewController(withIdentifier: "MyTabBarController") {
            destinationViewController.modalPresentationStyle = .fullScreen
            present(destinationViewController, animated: true, completion: nil)
        }
    }
    
    func ShowAlert(message: String) {
        let alertController = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(okAction)
        present(alertController, animated: true, completion: nil)
    }
}
