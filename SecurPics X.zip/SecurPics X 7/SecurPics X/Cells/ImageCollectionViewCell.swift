import UIKit

protocol FavoriteCollectionViewCellDelegate: AnyObject {
    func favoriteButtonTapped(at indexPath: IndexPath)
}

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var favoriteButton: UIButton!
    
    weak var delegate: FavoriteCollectionViewCellDelegate?
    var indexPath: IndexPath?
    var isFavorite = false
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    @IBAction func favoriteButtonTapped(_ sender: UIButton) {
        guard let indexPath = self.indexPath else { return }
        isFavorite.toggle()
        delegate?.favoriteButtonTapped(at: indexPath)
        
        updateFavoriteButtonAppearance()
    }
    
    func configure(with image: UIImage, at indexPath: IndexPath, isFavorite: Bool) {
        imgView.image = image
        self.indexPath = indexPath
        self.isFavorite = isFavorite
        updateFavoriteButtonAppearance()
    }
    
    func updateFavoriteButtonAppearance() {
        let imageName = isFavorite ? "heart.fill.red" : "heart"
        let image = UIImage(systemName: imageName)
        favoriteButton.setImage(image, for: .normal)
    }
}
