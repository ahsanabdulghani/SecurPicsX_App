import UIKit

class FavoriteCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
}
